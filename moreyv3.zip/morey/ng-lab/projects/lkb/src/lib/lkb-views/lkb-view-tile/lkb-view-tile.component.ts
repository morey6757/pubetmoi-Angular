import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lkb-view-tile',
  templateUrl: './lkb-view-tile.component.html',
  styleUrls: ['./lkb-view-tile.component.scss']
})
export class LkbViewTileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
