import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LkbService {

  constructor() { }
}
