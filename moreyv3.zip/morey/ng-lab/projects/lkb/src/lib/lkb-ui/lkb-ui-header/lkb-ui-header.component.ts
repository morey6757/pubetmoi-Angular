import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lkb-ui-header',
  templateUrl: './lkb-ui-header.component.html',
  styleUrls: ['./lkb-ui-header.component.scss']
})
export class LkbUiHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
