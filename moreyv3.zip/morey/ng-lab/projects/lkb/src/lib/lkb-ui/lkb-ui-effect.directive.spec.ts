import { LkbUiEffectDirective } from './lkb-ui-effect.directive';

describe('LkbUiEffectDirective', () => {
  it('should create an instance', () => {
    const directive = new LkbUiEffectDirective();
    expect(directive).toBeTruthy();
  });
});
