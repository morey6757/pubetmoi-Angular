import { Injectable } from '@angular/core';
import { ConnectorService } from './connector.service';
import { BrokerService } from './broker.service';

@Injectable()
export class SearchService {

  constructor(private broker:BrokerService, private connector:ConnectorService) { }
}
