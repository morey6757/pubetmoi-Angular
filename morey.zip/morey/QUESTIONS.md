
* Difeerence ngOnInit et ng AfterViewInit