import { SelectPipe } from './select.pipe';

describe('SelectPipe', () => {
  it('create an instance', () => {
    const pipe = new SelectPipe();
    expect(pipe).toBeTruthy();
  });
});
