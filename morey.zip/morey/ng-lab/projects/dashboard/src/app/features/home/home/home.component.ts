import { Component, OnInit, Inject } from "@angular/core";
import { StoreService } from "../../../core/store.service";
import { ActionTypes } from "../../../core/action-types.enum";
import { Subject, BehaviorSubject, merge, concat, combineLatest } from "rxjs";
import { SubSink } from "subsink";
import {
  delay,
  debounceTime,
  tap,
  skipUntil,
  switchMap,
  debounce,
  throttle,
  startWith,
  distinctUntilChanged
} from "rxjs/operators";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  private subs = new SubSink();

  click$ = new Subject();
  connecting$ = new Subject();
  merged$ = combineLatest(this.store.state$, this.connecting$);

  credentials = {
    username: "",
    password: ""
  };

  constructor(
    //@Inject(StoreService) private store:StoreService
    public store: StoreService
  ) {}

  /**
   *
   */
  ngOnInit() {
    this.subs.sink = this.connecting$.subscribe(console.log);

    this.subs.sink = this.click$
      .pipe(
        // debounceTime(300),

        throttle(() => {
          this.connecting$.next(true);
          this.connect();
          return this.store.state$;
        }),
        switchMap(() => this.store.state$),
      )
      .subscribe(data => {
        this.connecting$.next(false);
      });
  }

  /**
   * Conect Me !
   */
  connect() {
    this.store.dispatch({ type: ActionTypes.AUTH, data: this.credentials });
  }

  /**
   *Unsubscribe
   */
  ngOnDestroy() {
    this.subs.unsubscribe();
  }
}
