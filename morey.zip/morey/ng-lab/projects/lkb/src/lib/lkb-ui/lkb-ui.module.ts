import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LkbUiButtonComponent } from './lkb-ui-button/lkb-ui-button.component';
import { LkbUiHeaderComponent } from './lkb-ui-header/lkb-ui-header.component';
import { LkbUiLayoutComponent } from './lkb-ui-layout/lkb-ui-layout.component';
import { LkbUiCardComponent } from './lkb-ui-card/lkb-ui-card.component';
import { LkbUiEffectDirective } from './lkb-ui-effect.directive';
import { LkbUiFormatDirective } from './lkb-ui-format.directive';
import { LkbUiFilterPipe } from './lkb-ui-filter.pipe';
import { LkbUiContextComponent } from './lkb-ui-context/lkb-ui-context.component';


@NgModule({
  declarations: [
    LkbUiButtonComponent,
    LkbUiHeaderComponent,
    LkbUiLayoutComponent,
    LkbUiCardComponent,
    LkbUiEffectDirective,
    LkbUiFormatDirective,
    LkbUiFilterPipe,
    LkbUiContextComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    LkbUiButtonComponent,
    LkbUiHeaderComponent,
    LkbUiLayoutComponent,
    LkbUiCardComponent,
    LkbUiEffectDirective,
    LkbUiFormatDirective,
    LkbUiFilterPipe,
    LkbUiContextComponent
  ]})
export class LkbUiModule { }
